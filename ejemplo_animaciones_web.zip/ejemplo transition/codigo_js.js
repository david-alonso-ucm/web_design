// JavaScript Document

var size = "small";

function changeSize(id_element){

	var element = document.getElementById(id_element);
	
	if(size == "small"){
		element.style.transition = "width 2s, height 4s";
		element.style.width = "300px";
		element.style.height = "300px";
		size = "big";

	}
	else{
		element.style.transition = "width 2s, height 4s, box-shadow 5s";
		element.style.width = "100px";
		element.style.height = "100px";
		size = "small";
	
	}

}